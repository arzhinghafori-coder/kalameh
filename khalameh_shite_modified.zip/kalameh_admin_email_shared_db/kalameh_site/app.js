// اتصال از پنجره تنظیمات انجام می‌شود؛ فقط کلید عمومی Publishable/anon را وارد کن.
let SUPABASE_URL = (window.KALAMEH_CONFIG && window.KALAMEH_CONFIG.supabaseUrl) || localStorage.getItem("kalameh_supabase_url") || "";
let SUPABASE_ANON_KEY = (window.KALAMEH_CONFIG && window.KALAMEH_CONFIG.supabaseAnonKey) || localStorage.getItem("kalameh_supabase_key") || "";
let configured = false;
let db = null;
let authRecoverySubscription = null;
function initSupabase(url, key) {
  SUPABASE_URL = (url || "").trim().replace(/\/$/, "");
  SUPABASE_ANON_KEY = (key || "").trim();
  configured = /^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(SUPABASE_URL) && !!SUPABASE_ANON_KEY && !/service_role|secret/i.test(SUPABASE_ANON_KEY);
  db = configured ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;
  if (authRecoverySubscription) { authRecoverySubscription.unsubscribe(); authRecoverySubscription = null; }
  if (db) {
    const { data } = db.auth.onAuthStateChange((event) => {
      if (event === "PASSWORD_RECOVERY") {
        // Defer DOM work until after Supabase finishes its auth callback.
        setTimeout(() => {
          const loginPanel = document.getElementById("adminLoginPanel");
          const recoveryPanel = document.getElementById("adminRecoveryPanel");
          const adminDialog = document.getElementById("adminDialog");
          if (loginPanel && recoveryPanel && adminDialog) {
            loginPanel.classList.add("hidden");
            recoveryPanel.classList.remove("hidden");
            document.getElementById("adminMessage").textContent = "هویت شما تأیید شد. رمز جدید را وارد کن.";
            if (!adminDialog.open) adminDialog.showModal();
          }
        }, 0);
      }
    });
    authRecoverySubscription = data.subscription;
  }
  return configured;
}
if (SUPABASE_URL && SUPABASE_ANON_KEY) initSupabase(SUPABASE_URL, SUPABASE_ANON_KEY);
const $ = id => document.getElementById(id);
const state = {lang:"fa",answer:"",guesses:[],active:false,user:null,authMode:"register",keyboard:{},adminSession:null};
const words = {fa:["باران","مدرسه","پرنده","ستاره","پنجره","کتابی","بهاری","لبخند","باربد","نارنج"],en:["crane","apple","grape","house","plant","water","dream","smile","brain","light"]};
const keyboards = {fa:["ض ص ث ق ف غ ع ه خ ح ج چ","ش س ی ب ل ا ت ن م ک گ","ظ ط ز ر ذ د پ و"],en:["qwertyuiop","asdfghjkl","zxcvbnm"]};
const faDigits=n=>String(n).replace(/\d/g,d=>"۰۱۲۳۴۵۶۷۸۹"[d]);
function show(page){["setup","game","leaderboard","profile","tournaments"].forEach(id=>$(id).classList.toggle("hidden",id!==page));document.querySelectorAll(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.page===page));}
function say(t,type=""){$("message").textContent=t;$("message").className="message "+type;}
function setLang(lang){state.lang=lang;document.documentElement.lang=lang==="fa"?"fa":"en";document.documentElement.dir=lang==="fa"?"rtl":"ltr";document.querySelectorAll(".lang").forEach(b=>b.classList.toggle("active",b.dataset.lang===lang));$("gameTitle").textContent=lang==="fa"?"واژه پنج‌حرفی را پیدا کن":"Guess the five-letter word";renderKeyboard();}
function newGame(){if(!state.user){openAuth("register");return;}state.answer=words[state.lang][Math.floor(Math.random()*words[state.lang].length)];state.guesses=[];state.current="";state.active=true;state.keyboard={};$("attemptCount").textContent=state.lang==="fa"?"۰":"0";say(state.lang==="fa"?"یک واژه پنج‌حرفی وارد کن.":"Enter a five-letter word.");renderBoard();renderKeyboard();show("game");}
function evaluate(guess,answer){const g=Array.from(guess),a=Array.from(answer),out=Array(5).fill("gray"),counts={};for(let i=0;i<5;i++){if(g[i]===a[i])out[i]="green";else counts[a[i]]=(counts[a[i]]||0)+1;}for(let i=0;i<5;i++){if(out[i]!=="green"&&counts[g[i]]>0){out[i]="yellow";counts[g[i]]--;}}return out;}
function renderBoard(){const board=$("board");board.innerHTML="";for(let r=0;r<6;r++){const row=document.createElement("div");row.className="board-row";const guess=state.guesses[r]||"",letters=Array.from(guess);for(let c=0;c<5;c++){const tile=document.createElement("div");tile.className="tile";if(letters[c]){tile.textContent=letters[c];tile.classList.add("filled");}if(state.guesses[r])tile.classList.add(evaluate(state.guesses[r],state.answer)[c]);row.appendChild(tile);}board.appendChild(row);}$("attemptCount").textContent=faDigits(state.guesses.length);}
function renderKeyboard(){const root=$("keyboard");if(!root)return;root.innerHTML="";keyboards[state.lang].forEach(line=>{const row=document.createElement("div");row.className="key-row";for(const letter of Array.from(line.replaceAll(" ",""))){const key=document.createElement("button");key.className="key";key.textContent=letter;if(state.keyboard[letter])key.classList.add(state.keyboard[letter]);key.onclick=()=>addLetter(letter);row.appendChild(key);}root.appendChild(row);});const row=document.createElement("div");row.className="key-row";[["⌫","wide-key",removeLetter],[state.lang==="fa"?"ثبت":"ENTER","wide-key",submitGuess]].forEach(([label,cls,fn])=>{const b=document.createElement("button");b.className="key "+cls;b.textContent=label;b.onclick=fn;row.appendChild(b);});root.appendChild(row);}
function addLetter(ch){if(!state.active)return;const a=Array.from(state.current||"");if(a.length<5){a.push(ch);state.current=a.join("");renderCurrent();}}
function removeLetter(){if(!state.active)return;state.current=Array.from(state.current||"").slice(0,-1).join("");renderCurrent();}
function renderCurrent(){const row=$("board").children[state.guesses.length];if(!row)return;const a=Array.from(state.current||"");[...row.children].forEach((t,i)=>{t.textContent=a[i]||"";t.classList.toggle("filled",!!a[i]);});}
async function submitGuess(){if(!state.active)return;const guess=(state.current||"").normalize("NFC").toLowerCase();if(Array.from(guess).length!==5){say(state.lang==="fa"?"واژه باید دقیقاً ۵ حرف داشته باشد.":"Word must contain exactly 5 letters.","error");return;}state.guesses.push(guess);state.current="";const result=evaluate(guess,state.answer);Array.from(guess).forEach((ch,i)=>{const old=state.keyboard[ch],next=result[i];if(old!=="green"&&(old!=="yellow"||next==="green"))state.keyboard[ch]=next;});renderBoard();renderKeyboard();if(guess===state.answer){state.active=false;say(state.lang==="fa"?"آفرین! واژه را پیدا کردی 🎉":"You got it! 🎉","success");await saveResult(true);return;}if(state.guesses.length===6){state.active=false;say((state.lang==="fa"?"پایان بازی؛ پاسخ: ":"Game over. Answer: ")+state.answer,"error");await saveResult(false);return;}say(state.lang==="fa"?"حدس بعدی را امتحان کن.":"Try another guess.");}
async function saveResult(won){if(!state.user||!db)return;const {error}=await db.rpc("record_kalameh_result",{p_username:state.user.username,p_password:state.user.password,p_won:won,p_attempts:state.guesses.length,p_answer:state.answer,p_guesses:state.guesses});if(error){console.error(error);say("نتیجه در سرور ذخیره نشد. اتصال دیتابیس را بررسی کن.","error");}}
function openAuth(mode="register"){if(!db){$("authMessage").textContent="ابتدا تنظیمات Supabase در app.js را تکمیل کن.";}state.authMode=mode;updateAuthUI();$("authDialog").showModal();}
function updateAuthUI(){const login=state.authMode==="login";$("authTitle").textContent=login?"ورود به حساب":"ساخت حساب";$("nameLabel").classList.toggle("hidden",login);$("usernameLabel").classList.toggle("hidden",!login);$("authSubmit").textContent=login?"ورود":"ساخت حساب";$("passwordInput").value="";document.querySelectorAll(".auth-tabs button").forEach(b=>b.classList.toggle("active",b.dataset.auth===state.authMode));$("authMessage").textContent="";}
async function authSubmit(){
 if(!db){$('authMessage').textContent='ابتدا تنظیمات Supabase را در app.js وارد کن.';return;}
 const password=$('passwordInput').value;
 if(password.length<8){$('authMessage').textContent='رمز عبور باید حداقل ۸ نویسه باشد.';return;}
 const registering=state.authMode==='register';
 const username=(registering?$('registerUsername').value:$('usernameInput').value).trim().toLowerCase();
 if(!/^[a-z0-9_]{3,24}$/.test(username)){$('authMessage').textContent='نام کاربری باید ۳ تا ۲۴ نویسه و شامل حروف انگلیسی، عدد یا _ باشد.';return;}
 $('authSubmit').disabled=true;
 try{
   const fn=registering?'register_kalameh_player':'login_kalameh_player';
   const {data,error}=await db.rpc(fn,{p_username:username,p_password:password});
   if(error){
     const message=String(error.message||'');
     if(registering&&(message.includes('این نام کاربری قبلاً انتخاب شده')||message.includes('already exists')||message.includes('duplicate'))){
       throw new Error('این نام کاربری قبلاً ثبت شده است. لطفاً نام دیگری انتخاب کن یا وارد حساب قبلی‌ات شو.');
     }
     throw error;
   }
   const row=Array.isArray(data)?data[0]:data;
   if(!row||!row.username){
     if(registering)throw new Error('ثبت‌نام تأیید نشد. ممکن است این نام کاربری قبلاً استفاده شده باشد.');
     throw new Error('نام کاربری یا رمز عبور اشتباه است.');
   }
   state.user={username:row.username,password};
   sessionStorage.setItem('kalameh_session',JSON.stringify(state.user));
   if(registering)window.alert('ثبت‌نام با موفقیت تأیید شد! نام کاربری شما: '+row.username+'\nحالا می‌توانی بازی را شروع کنی.');
   $('authDialog').close();
   $('accountBtn').textContent='@'+row.username;
   $('guestNote').textContent='وارد حساب شده‌ای؛ نتایج بازی‌ها ذخیره می‌شوند.';
   await loadProfile();
   newGame();
 }catch(e){$('authMessage').textContent=e.message||'خطا در ورود یا ثبت‌نام.';}
 finally{$('authSubmit').disabled=false;}
}
async function loadProfile(){if(!state.user||!db)return;const {data,error}=await db.rpc("get_kalameh_profile",{p_username:state.user.username,p_password:state.user.password});if(error||!data?.length)return;const p=data[0];$("profileName").textContent=p.username;$("profileUsername").textContent="@"+p.username;$("statGames").textContent=faDigits(p.games);$("statWins").textContent=faDigits(p.wins);$("statBest").textContent=p.best_attempts?faDigits(p.best_attempts):"—";const xp=p.wins*100+p.games*20,lv=Math.floor(xp/250)+1,pr=Math.round(xp%250/250*100);$("profileLevel").textContent=(lv<3?"تازه‌کار":lv<6?"واژه‌جو":lv<10?"استاد واژه":"افسانه‌ای")+" · سطح "+faDigits(lv);$("levelProgress").style.width=pr+"%";$("levelXp").textContent=faDigits(xp)+" امتیاز تجربه · "+faDigits(pr)+"٪ تا سطح بعد";const hist=$("profileHistory");if(hist){const {data:rows,error:he}=await db.rpc("get_kalameh_history",{p_username:state.user.username,p_password:state.user.password});hist.innerHTML="";if(he||!rows?.length){hist.innerHTML="<div class=loading>هنوز سابقه‌ای در دسترس نیست.</div>";return;}rows.forEach(h=>{const d=document.createElement("div");d.className="leader-row";d.textContent=(h.won?"🏆 برد":"🎮 باخت")+" · "+faDigits(h.attempts)+" حدس · "+new Date(h.played_at).toLocaleDateString();hist.appendChild(d);});}}
async function loadLeaderboard(){const root=$("leaderRows");root.innerHTML='<div class="loading">در حال دریافت جدول...</div>';if(!db){root.innerHTML='<div class="loading">برای نمایش جدول، ابتدا دیتابیس را تنظیم کن.</div>';return;}const {data,error}=await db.rpc("get_kalameh_leaderboard");if(error){root.innerHTML='<div class="loading">دریافت جدول ناموفق بود.</div>';return;}root.innerHTML="";if(!data?.length){root.innerHTML='<div class="loading">هنوز رکوردی ثبت نشده است.</div>';return;}data.forEach((p,i)=>{const row=document.createElement("div");row.className="leader-row";row.innerHTML=`<span class="rank">${i+1}</span><span class="leader-name"><b></b><small></small></span><span class="leader-wins">${p.wins} برد</span>`;row.querySelector("b").textContent=p.username;row.querySelector("small").textContent="@"+p.username;root.appendChild(row);});}
async function loadTournament(){const root=$("tournamentRows");if(!root)return;root.innerHTML='<div class="loading">در حال دریافت جدول مسابقه هفتگی...</div>';if(!db){root.innerHTML='<div class="loading">برای مشاهده مسابقات، ابتدا اتصال دیتابیس را تنظیم کن.</div>';return;}const {data,error}=await db.rpc("get_kalameh_weekly_tournament");if(error){root.innerHTML='<div class="loading">جدول مسابقه در دسترس نیست. فایل SQL به‌روزرسانی‌شده را در Supabase اجرا کن.</div>';return;}root.innerHTML="";const rows=data||[];const games=rows.reduce((n,r)=>n+(r.games||0),0);if($("tournamentPlayers"))$("tournamentPlayers").textContent=faDigits(rows.length);if($("tournamentGames"))$("tournamentGames").textContent=faDigits(games);if(!rows.length){root.innerHTML='<div class="loading">هنوز در این هفته بازی ثبت نشده است. اولین نفر باش!</div>';return;}rows.forEach((p,i)=>{const row=document.createElement("div");row.className="leader-row";row.innerHTML=`<span class="rank">${i+1}</span><span class="leader-name"><b></b><small></small></span><span class="leader-wins">${faDigits(p.wins)} برد · ${faDigits(p.games)} بازی</span>`;row.querySelector("b").textContent=p.username;row.querySelector("small").textContent="@"+p.username;root.appendChild(row);});}
function logout(){state.user=null;sessionStorage.removeItem("kalameh_session");$("accountBtn").textContent="ورود / ثبت‌نام";$("guestNote").textContent="برای بازی باید ثبت‌نام کنی یا وارد حساب شوی.";state.active=false;show("setup");}
async function adminRequest(action){
  const {data:{session}}=await db.auth.getSession();
  if(!session?.access_token)throw new Error("ابتدا با حساب مدیر وارد شو.");
  const resp=await fetch(`${SUPABASE_URL}/functions/v1/kalameh-admin`,{method:"POST",headers:{"Content-Type":"application/json","apikey":SUPABASE_ANON_KEY,"Authorization":`Bearer ${session.access_token}`},body:JSON.stringify({action})});
  const data=await resp.json().catch(()=>({error:"پاسخ نامعتبر از سرور"}));
  if(!resp.ok)throw new Error(data.error||"درخواست مدیر ناموفق بود.");return data;
}
function drawAdminActivity(history){
  const canvas=$("adminActivityChart");if(!canvas)return;
  const ctx=canvas.getContext("2d");if(!ctx)return;
  const dpr=window.devicePixelRatio||1,w=Math.max(300,canvas.clientWidth||520),h=160;
  canvas.width=w*dpr;canvas.height=h*dpr;ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);
  const dayMs=86400000,now=new Date(),today=new Date(now.getFullYear(),now.getMonth(),now.getDate());
  const vals=Array(7).fill(0);
  (history||[]).forEach(item=>{const d=new Date(item.played_at);const day=new Date(d.getFullYear(),d.getMonth(),d.getDate());const diff=Math.round((today-day)/dayMs);if(diff>=0&&diff<7)vals[6-diff]++;});
  const max=Math.max(1,...vals),pad=18,gap=12,bw=(w-pad*2-gap*6)/7;
  const styles=getComputedStyle(document.body),muted=styles.getPropertyValue("--muted").trim()||"#8b9bb4";
  ctx.font="11px sans-serif";ctx.textAlign="center";
  vals.forEach((v,i)=>{const bh=(h-42)*(v/max),x=pad+i*(bw+gap),y=h-26-bh;const grad=ctx.createLinearGradient(0,y,0,h-26);grad.addColorStop(0,"#25e3b7");grad.addColorStop(1,"#625bff");ctx.fillStyle=grad;ctx.beginPath();ctx.roundRect(x,y,bw,Math.max(3,bh),7);ctx.fill();ctx.fillStyle=muted;ctx.fillText(["۶روز","۵روز","۴روز","۳روز","۲روز","دیروز","امروز"][i],x+bw/2,h-8);ctx.fillStyle=muted;ctx.fillText(String(v),x+bw/2,Math.max(12,y-6));});
}
async function adminLogin(){
  if(!configured){$("adminMessage").textContent="اتصال مشترک Supabase را در config.js تنظیم کن.";return;}
  const email=$("adminEmail").value.trim().toLowerCase(),password=$("adminPassword").value;
  if(email!=="arzhinghafori@gmail.com"){ $("adminMessage").textContent="این حساب مجاز به مدیریت نیست.";return; }
  if(!password){$("adminMessage").textContent="رمز حساب مدیر را وارد کن.";return;}
  $("adminLoginBtn").disabled=true;
  try{
    const {data,error}=await db.auth.signInWithPassword({email,password});
    if(error)throw error;
    if((data.user?.email||"").toLowerCase()!=="arzhinghafori@gmail.com"||!data.user?.email_confirmed_at){await db.auth.signOut();throw new Error("ایمیل مدیر باید تأیید شده و دقیقاً همان ایمیل مجاز باشد.");}
    await refreshAdminOverview();
    $("adminLoginPanel").classList.add("hidden");$("adminContent").classList.remove("hidden");$("adminMessage").textContent="ورود مدیر با موفقیت تأیید شد.";
  }catch(e){try{await db.auth.signOut();}catch(_){}$("adminMessage").textContent=e.message||"ورود مدیر ناموفق بود.";}
  finally{$("adminLoginBtn").disabled=false;}
}

async function sendAdminPasswordRecovery(){
  if(!configured || !db){$("adminMessage").textContent="اتصال Supabase تنظیم نیست.";return;}
  const email=$("adminEmail").value.trim().toLowerCase();
  if(email!=="arzhinghafori@gmail.com"){ $("adminMessage").textContent="این ایمیل مجاز به مدیریت نیست.";return; }
  const button=$("adminForgotPasswordBtn");button.disabled=true;
  try{
    // Supabase redirects to the project's configured Site URL. Set that URL to the deployed site.
    const {error}=await db.auth.resetPasswordForEmail(email);
    if(error)throw error;
    $("adminMessage").textContent="اگر حساب و تنظیمات ایمیل درست باشد، لینک بازیابی برای ایمیل مدیر ارسال می‌شود. پوشهٔ Spam را هم بررسی کن.";
  }catch(e){$("adminMessage").textContent=e.message||"ارسال لینک بازیابی ناموفق بود.";}
  finally{button.disabled=false;}
}
async function saveAdminNewPassword(){
  const password=$("adminNewPassword").value,confirm=$("adminConfirmPassword").value;
  if(password.length<10){$("adminMessage").textContent="رمز جدید باید حداقل ۱۰ نویسه داشته باشد.";return;}
  if(password!==confirm){$("adminMessage").textContent="دو رمز واردشده یکسان نیستند.";return;}
  const button=$("adminSaveNewPasswordBtn");button.disabled=true;
  try{
    const {data,error}=await db.auth.updateUser({password});
    if(error)throw error;
    if((data.user?.email||"").toLowerCase()!=="arzhinghafori@gmail.com"){
      await db.auth.signOut();throw new Error("این حساب، حساب مدیر مجاز نیست.");
    }
    $("adminNewPassword").value="";$("adminConfirmPassword").value="";
    $("adminRecoveryPanel").classList.add("hidden");
    try{
      await refreshAdminOverview();
      $("adminContent").classList.remove("hidden");
      $("adminLoginPanel").classList.add("hidden");
      $("adminMessage").textContent="رمز جدید ذخیره شد و ورود مدیر انجام شد.";
    }catch(panelError){
      await db.auth.signOut();
      $("adminLoginPanel").classList.remove("hidden");
      $("adminContent").classList.add("hidden");
      $("adminMessage").textContent="رمز جدید با موفقیت ذخیره شد؛ اما خود پنل هنوز آماده نیست. تابع kalameh-admin را در Supabase منتشر و Secrets سرور را تنظیم کن. جزئیات: "+(panelError.message||"خطای پنل");
    }
  }catch(e){$("adminMessage").textContent=e.message||"ذخیره رمز جدید ناموفق بود. لینک بازیابی ممکن است منقضی شده باشد.";}
  finally{button.disabled=false;}
}
function cancelAdminRecovery(){
  $("adminRecoveryPanel").classList.add("hidden");$("adminLoginPanel").classList.remove("hidden");
  $("adminNewPassword").value="";$("adminConfirmPassword").value="";
  $("adminMessage").textContent="";
}

async function refreshAdminOverview(){
  const data=await adminRequest("overview"),users=data.users||[],history=data.history||[];
  const wins=users.reduce((n,u)=>n+(u.wins||0),0),games=Number(data.games||0),rate=games?Math.round(wins/games*100):0;
  $("adminUsers").textContent=faDigits(users.length);$("adminGames").textContent=faDigits(games);$("adminWins").textContent=faDigits(wins);$("adminWinRate").textContent=faDigits(rate)+"٪";
  $("adminUserRows").innerHTML="";users.forEach(p=>{const d=document.createElement("div");d.className="leader-row";d.textContent=`@${p.username} — ${faDigits(p.games||0)} بازی · ${faDigits(p.wins||0)} برد`;$ ("adminUserRows").appendChild(d);});
  $("adminHistoryRows").innerHTML="";history.slice(0,60).forEach(h=>{const d=document.createElement("div");d.className="leader-row";d.textContent=`@${h.username} — ${h.won?"برد":"باخت"} — ${faDigits(h.attempts)} حدس — ${new Date(h.played_at).toLocaleString("fa-IR")}`;$("adminHistoryRows").appendChild(d);});
  drawAdminActivity(history);
}
async function adminLogout(){try{await db?.auth.signOut();}finally{$("adminContent").classList.add("hidden");$("adminLoginPanel").classList.remove("hidden");$("adminPassword").value="";$("adminMessage").textContent="از پنل مدیریت خارج شدی.";}}
function openDbSettings(){
  $("supabaseUrlInput").value=SUPABASE_URL;
  $("supabaseKeyInput").value=SUPABASE_ANON_KEY;
  $("dbSettingsMessage").textContent="";
  $("dbSettingsDialog").showModal();
}
function saveDbSettings(){
  const url=$("supabaseUrlInput").value.trim();
  const key=$("supabaseKeyInput").value.trim();
  if(!initSupabase(url,key)){ $("dbSettingsMessage").textContent="آدرس پروژه یا کلید عمومی معتبر نیست. کلید Publishable یا anon را وارد کن، نه service_role."; return; }
  if(!(window.KALAMEH_CONFIG && window.KALAMEH_CONFIG.supabaseUrl)){localStorage.setItem("kalameh_supabase_url",SUPABASE_URL);localStorage.setItem("kalameh_supabase_key",SUPABASE_ANON_KEY);}
  $("dbSettingsDialog").close();
  $("guestNote").textContent="اتصال Supabase تنظیم شد. حالا می‌توانی ثبت‌نام کنی.";
  say("اتصال Supabase ذخیره شد.","success");
}
$("dbSettingsBtn").onclick=openDbSettings;
$("saveDbSettingsBtn").onclick=saveDbSettings;
document.querySelectorAll(".lang").forEach(b=>b.onclick=()=>setLang(b.dataset.lang));document.querySelectorAll(".nav-btn").forEach(b=>b.onclick=()=>{if(b.dataset.page==="game"&&!state.user){openAuth("register");return;}show(b.dataset.page);if(b.dataset.page==="leaderboard")loadLeaderboard();if(b.dataset.page==="profile")loadProfile();if(b.dataset.page==="tournaments")loadTournament();});document.querySelectorAll(".auth-tabs button").forEach(b=>b.onclick=()=>{state.authMode=b.dataset.auth;updateAuthUI();});
$("startBtn").onclick=()=>state.user?newGame():openAuth("register");$("newGameBtn").onclick=newGame;$("backBtn").onclick=()=>show("setup");$("accountBtn").onclick=()=>openAuth(state.user?"login":"register");$("authSubmit").onclick=authSubmit;$("refreshBoard").onclick=loadLeaderboard;$("logoutBtn").onclick=logout;$("adminBtn").onclick=()=>{$("adminDialog").showModal();};$("adminLoginBtn").onclick=adminLogin;$("adminLogoutBtn").onclick=adminLogout;$("adminForgotPasswordBtn").onclick=sendAdminPasswordRecovery;$("adminSaveNewPasswordBtn").onclick=saveAdminNewPassword;$("adminCancelRecoveryBtn").onclick=cancelAdminRecovery;if($("adminRefreshBtn"))$("adminRefreshBtn").onclick=()=>refreshAdminOverview().catch(e=>$("adminMessage").textContent=e.message);
document.addEventListener("keydown",e=>{if($("authDialog").open||$("adminDialog").open||!state.active||$("game").classList.contains("hidden"))return;if(e.key==="Enter")submitGuess();else if(e.key==="Backspace")removeLetter();else if(state.lang==="en"&&/^[a-z]$/i.test(e.key))addLetter(e.key.toLowerCase());});
try{const saved=sessionStorage.getItem("kalameh_session");if(saved){state.user=JSON.parse(saved);$("accountBtn").textContent="@"+state.user.username;$("guestNote").textContent="وارد حساب شده‌ای؛ نتایج بازی‌ها ذخیره می‌شوند.";}}catch{}
setLang("fa");renderBoard();renderKeyboard();

(function(){const b=$("themeToggle");if(!b)return;const apply=t=>{document.body.dataset.theme=t;localStorage.setItem("kalameh_theme",t);b.textContent=t==="light"?"🌙 حالت تاریک":"☀️ حالت روشن";};apply(localStorage.getItem("kalameh_theme")||"dark");b.onclick=()=>apply(document.body.dataset.theme==="light"?"dark":"light");})();if($("tournamentRefresh"))$("tournamentRefresh").onclick=loadTournament;
