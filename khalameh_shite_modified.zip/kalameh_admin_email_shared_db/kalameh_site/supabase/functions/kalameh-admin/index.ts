import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const ADMIN_EMAIL = "arzhinghafori@gmail.com";

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405, headers: corsHeaders });
  try {
    const authHeader = req.headers.get("Authorization") || "";
    const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
    if (!token) return Response.json({ error: "ورود مدیر الزامی است." }, { status: 401, headers: corsHeaders });
    const url = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!url || !serviceKey) throw new Error("Server secrets are not configured");
    const admin = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
    // Verify the signed Supabase Auth JWT with the Auth server; never trust a client-supplied email.
    const { data: { user }, error: authError } = await admin.auth.getUser(token);
    if (authError || !user || (user.email || "").toLowerCase() !== ADMIN_EMAIL || !user.email_confirmed_at) {
      return Response.json({ error: "این حساب اجازه دسترسی به پنل مدیریت را ندارد." }, { status: 403, headers: corsHeaders });
    }
    const body = await req.json().catch(() => ({}));
    if (body.action !== "overview") return Response.json({ error: "Unknown action" }, { status: 400, headers: corsHeaders });
    const [{ data: users, error: usersError }, { data: history, error: historyError }] = await Promise.all([
      admin.from("kalameh_players").select("username,created_at,games,wins,losses,best_attempts").order("created_at", { ascending: false }).limit(500),
      admin.from("kalameh_history").select("username,won,attempts,played_at").order("played_at", { ascending: false }).limit(500),
    ]);
    if (usersError) throw usersError;
    if (historyError) throw historyError;
    return Response.json({ users: users ?? [], history: history ?? [], games: (users ?? []).reduce((n, u) => n + (u.games || 0), 0) }, { headers: corsHeaders });
  } catch (e) {
    return Response.json({ error: e instanceof Error ? e.message : "Server error" }, { status: 500, headers: corsHeaders });
  }
});
